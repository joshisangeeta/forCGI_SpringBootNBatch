package com.sj.batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbatchdemo0ApplicationTests {

	@Test
	void contextLoads() {
	}

}
