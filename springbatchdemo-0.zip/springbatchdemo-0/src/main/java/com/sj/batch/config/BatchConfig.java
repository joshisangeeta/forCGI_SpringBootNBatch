/**
 * 
 */
package com.sj.batch.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sj.batch.tasks.GameLoad;
import com.sj.batch.tasks.PlaySummarization;
import com.sj.batch.tasks.PlayerLoad;

/**
 * @author HP
 *
 */
@Configuration
@EnableBatchProcessing
public class BatchConfig {
	
	@Autowired
	JobBuilderFactory jobs;
	
	@Autowired
	StepBuilderFactory steps;
	
	@Bean
	public Job footballJob() {
		
		
		return this.jobs.get("footballJob").start(playerLoad()).next(gameLoad()).next(playSummarization()).build();
		
		
	}
	
	
	@Bean
	public Step playerLoad() {
		
	     return steps.get("playerLoad").tasklet(new PlayerLoad()).build();
	
	}
	
	
   @Bean 
   public Step gameLoad() {
	   
	   return steps.get("gameLoad").tasklet(new GameLoad()).build();
   }
	
	
   @Bean
   public Step playSummarization() {
	   return steps.get("playSummarizatoin").tasklet(new PlaySummarization()).build();
   }
   
   
   
   
   
   
   
   
   
	
	
	

}
