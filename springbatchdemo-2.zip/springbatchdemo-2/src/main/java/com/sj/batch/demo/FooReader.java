/**
 * 
 */
package com.sj.batch.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

import com.sj.batch.model.Foo;

/**
 * @author HP
 *
 */

public class FooReader implements ItemReader<Foo> {
	List <Foo> fooList ;
	
	int nextFooIndex;
	
	
	public FooReader() {
		initialize();
		 
		
	}
  
	
	private void initialize() {
		// TODO Auto-generated method stub
		 Foo f1 = new  Foo(1);	
		 Foo f2 =new Foo(2);
		 Foo f3 =new Foo(3);
	    fooList =Collections.unmodifiableList(Arrays.asList(f1,f2,f3));
	
	      nextFooIndex=0;
	}


	@Override
	public Foo read() throws Exception {
		// TODO Auto-generated method stub
		Foo nextFoo =null;
		if(nextFooIndex < fooList.size()) {
			
		    nextFoo = fooList.get(nextFooIndex);
		    nextFooIndex++;
		}
		
		
		
		return nextFoo;
	     
    
	}
}
