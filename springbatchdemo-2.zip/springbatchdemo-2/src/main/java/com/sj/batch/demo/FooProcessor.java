/**
 * 
 */
package com.sj.batch.demo;

import org.springframework.batch.item.ItemProcessor;

import com.sj.batch.model.Bar;
import com.sj.batch.model.Foo;

/**
 * @author HP
 *
 */
public class FooProcessor implements ItemProcessor<Foo,Bar> {

	@Override
	public Bar process(Foo item) throws Exception {
		// TODO Auto-generated method stub
		
		return new Bar(item);
		
	}
	
	
	
	

}
