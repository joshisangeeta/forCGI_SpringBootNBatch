/**
 * 
 */
package com.sj.batch;

import java.util.ArrayList;
import java.util.stream.Stream;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sj.batch.demo.BarWriter;
import com.sj.batch.demo.FooProcessor;
import com.sj.batch.demo.FooReader;
import com.sj.batch.listeners.NoWorkFoundStepExecutionListener;
import com.sj.batch.model.Bar;
import com.sj.batch.model.Foo;

/**
 * @author HP
 *
 */
@Configuration
@EnableBatchProcessing
public class BeanConfig {	
	
	@Autowired
	JobBuilderFactory jobs;
	
	@Autowired
	StepBuilderFactory steps;
	
	
	@Bean
	public Job ioSimpleJob() {
		
		return jobs.get("ioSimpleJob").start(step1()).build();
		
	}
	
	@Bean
	public Step step1() {
		
		return steps.get("step1").listener(new NoWorkFoundStepExecutionListener()).<Foo,Bar>chunk(2).reader(fooReader()).processor(fooProcessor()).writer(barWriter()).build();
		
	}
	
	@Bean
	public  FooProcessor fooProcessor() {
		// TODO Auto-generated method stub
		return new FooProcessor();
	}
	
	@Bean
	public ItemWriter<? super Bar> barWriter(){
		return new BarWriter();
		
	}
	

	@Bean 
	public ItemReader<Foo> fooReader(){
		
		return new FooReader();
		
	     
		//return new FooReader();
	}
	
	
	
	
	

}
