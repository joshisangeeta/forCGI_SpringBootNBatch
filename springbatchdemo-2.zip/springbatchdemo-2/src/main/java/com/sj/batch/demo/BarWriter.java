/**
 * 
 */
package com.sj.batch.demo;

import java.io.Serializable;
import java.util.List;

import org.springframework.batch.item.ItemWriter;

import com.sj.batch.model.Bar;

/**
 * @author HP
 *
 */
public class BarWriter implements ItemWriter<Bar>{

	@Override
	public void write(List<? extends Bar> items) throws Exception {
		// TODO Auto-generated method stub
		
	    for(Bar b:items) {
	    	if (b!=null)
		System.out.println("Writing bars"+items );
		
	}
	    
	}
	

	
}


