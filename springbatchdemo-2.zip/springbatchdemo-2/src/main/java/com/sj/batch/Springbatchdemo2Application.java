package com.sj.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbatchdemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbatchdemo2Application.class, args);
	}

}


