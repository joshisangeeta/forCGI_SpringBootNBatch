/**
 * 
 */
package com.sj.batch.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sj.batch.tasks.MyTaskOne;
import com.sj.batch.tasks.MyTaskTwo;

/**
 * @author SJ
 *
 */
@Configuration
@EnableBatchProcessing
public class BatchConfig {
    
	@Autowired
	JobBuilderFactory jobs;
	
	@Autowired
	StepBuilderFactory steps;
	
	@Bean
	public Step stepOne() {
		
		return steps.get("stepOne").tasklet(new MyTaskOne()).build();
		
	}
	
	@Bean
	public Step stepTwo() {
		return steps.get("stepTwo").tasklet(new MyTaskTwo()).build();
	}
	
	@Bean
	public Job demoJob() {
	//return jobs.get("demoJob").start(stepOne()).next(stepTwo()).build();
		
		return jobs.get("demoJob").incrementer(new RunIdIncrementer()).start(stepOne()).next(stepTwo()).build();
	}
	
	
	
	
	
	
	
	
}
