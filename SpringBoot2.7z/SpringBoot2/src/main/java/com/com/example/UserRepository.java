package com.example;
/**
 * 
 */


import org.springframework.data.jpa.repository.JpaRepository;



/**
 * @author sangeeta
 *
 */
public interface UserRepository extends JpaRepository<User, Integer>
{
}